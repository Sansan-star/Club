import './src/script/component/app-bar.js';
import main from './src/script/view/main.js';

document.addEventListener('DOMContentLoaded', main);
